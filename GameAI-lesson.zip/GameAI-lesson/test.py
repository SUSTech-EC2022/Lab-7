"""
@DATE: 2021/7/13
@Author: Ziqi Wang
@File: test.py
"""
import numpy as np
import time

if __name__ == '__main__':
    arr = np.array([[2, 3, 9, 1], [2, 1, 0, 4]])
    print(arr[1].argmax())
